-- AlterTable
ALTER TABLE "ExamSession" ADD COLUMN     "isIntelligent" BOOLEAN DEFAULT false;
